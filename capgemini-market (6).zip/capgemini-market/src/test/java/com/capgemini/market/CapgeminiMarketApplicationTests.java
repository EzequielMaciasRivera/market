package com.capgemini.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapgeminiMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
